package salesforce.to.grafo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Arquivo {
	
	// Nome do arquivo a ser lido
	public String nomeDoArquivo;
	
	// Pasta raiz
	public String pastaRaiz;
	
	// Properties
	public Properties properties = new Properties();
	
	public Arquivo(String nomeDoArquivo, String pastaRaiz)
	{
		this.nomeDoArquivo = nomeDoArquivo;
		this.pastaRaiz = pastaRaiz;
		 
	}

	//Leitura de Arquivo
    public  List<String> leituraDeArquivo() 
    {
    	List<String> linhasArquivoLidas = new ArrayList<String>();
    	
	    try {
	    	
	    	String baseArquivo = pastaRaiz  + nomeDoArquivo;

	        File myObj = new File(baseArquivo);
	        Scanner myReader = new Scanner(myObj);
	        
	        while (myReader.hasNextLine()) {
	        	 
	          String data = myReader.nextLine();
	          
	          
	          System.out.println(data);
	          linhasArquivoLidas.add(data);
	          // verifica identificador da linha
	         /* if(data.startsWith(marcadorInicialdaLinha))
	        	{
	        	   
	        	  for(String tokenValor: ListTokenValor)
	        	  {
	        		 String conteudoDaLinha   = null;
	        		 String tokenTratado = new String();
	        		 
	        		 
	                 // Extrai conteudo da linha 
	                 Pattern pattern = Pattern.compile(tokenValor + "(.*?)" + tokenValor);
	                 Matcher matcher = pattern.matcher(data);
	                 while (matcher.find()) {
	                     conteudoDaLinha = matcher.group(1);
	                 }
	                 
	                 //Extrai conteudo do token
	                 Pattern patternToken = Pattern.compile("@" + "(.*?)" + "@");
	                 Matcher matcherToken = patternToken.matcher(tokenValor);
	                 while (matcherToken.find()) {
	                     tokenTratado = matcherToken.group(1);
	                 }        		 
	        		 
	        		 System.out.println("tokenTratado:" + tokenTratado);	        		 
	        		 System.out.println("conteudoDaLinha:" + conteudoDaLinha);
	        		 
	        		 if(conteudoDaLinha != null && conteudoDaLinha != " " && conteudoDaLinha != "")
	        		 {
	        			 System.out.println("Set Propertiers");
	        			 properties.setProperty(tokenTratado, conteudoDaLinha); 
	        		 }
	        		  
	        	  }   
	        	  
	        	}*/
  
	         // System.out.println(data);
	        }
	        myReader.close();
	        
	        System.out.println("Leitura do arquivo " + nomeDoArquivo + " realizada com sucesso");
	        return linhasArquivoLidas;
	      } catch (FileNotFoundException e) {
	        System.out.println("ocorreu um erro." + e);
	        e.printStackTrace();
	      }

    	return  linhasArquivoLidas;
    }
    
// retorna o propertiers com as informa��es salvas   
    public Properties returnProperties()
    {
    	return properties;
    }
    
 // Gravar no arquivo   
 public boolean gravarArquivo(String Linhadados)
 {
	    try {
	    	String baseArquivo = pastaRaiz + nomeDoArquivo;
	        FileWriter myWriter = new FileWriter(baseArquivo,true);
	        
	        BufferedWriter info = new BufferedWriter(myWriter);
	        
	        String dados = new String();
	        dados	= Linhadados;  
      	    
      	  // Gravar Linha de dados no arquivo
      	    //myWriter.write(dados);
	       // info.newLine();
	        info.write(Linhadados+"\n");
	        
	        info.close();
	        //myWriter.close();
	        
	        System.out.println("Grava��o do arquivo " + nomeDoArquivo + " realizada com sucesso");
	        return true;
	      } catch (Exception e) {
	        System.out.println("ocorreu um erro:" + e);
	        e.printStackTrace();
	      }
	 
	 return false;
 }
    
    
    
    
    
}
