package salesforce.to.grafo;

public class attributes {
	
	public String type;
	public String url;

}
