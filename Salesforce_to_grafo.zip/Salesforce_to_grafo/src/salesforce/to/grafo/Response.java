package salesforce.to.grafo;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Response {
	
	public Integer size;
	public Integer totalSize;
	public boolean done;
	public String  queryLocator;
	public String  entityTypeName;
	public List<Records> records;
} 
