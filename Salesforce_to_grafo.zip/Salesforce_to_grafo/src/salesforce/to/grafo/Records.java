package salesforce.to.grafo;

 

public class Records {
	
	public attributes attributes;
	
	public String MetadataComponentId;
	public String MetadataComponentName;
	public String MetadataComponentNamespace;
	public String MetadataComponentType;
	public String RefMetadataComponentId;
	public String RefMetadataComponentName;
	public String RefMetadataComponentNamespace;
	public String RefMetadataComponentType;

}

