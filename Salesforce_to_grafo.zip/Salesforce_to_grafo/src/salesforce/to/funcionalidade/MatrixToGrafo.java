package salesforce.to.funcionalidade;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

import salesforce.to.grafo.Arquivo;

public class MatrixToGrafo {
	
	// Fun��o criada para ler a matrix para extrair funcionalidades para grafo
	public static void main(String[] args) 
	{
		// Arquivo linhasArquivoLidas
		List<String> linhasArquivoLidas = new ArrayList<String>();
		
		//Definindo Arquivo
		Arquivo arquivoDeConta = new Arquivo("network.csv",".\\arquivo-csv\\");
		
		// Armazenar valores das vari�veis
		Map<String,Integer> mapaVertices = new HashMap<String,Integer>();
		Map<Integer,String> mapaVerticesText = new HashMap<Integer,String>();
		
		// armazena funcionalidades x compoenetes
		Map<String,String> mapaFuncionalidadesXcomponentes = new HashMap<String,String>();
		
		// Guarda subarvore
		Map<String,String> mapaSubArvore = new HashMap<String,String>();
		
		linhasArquivoLidas = arquivoDeConta.leituraDeArquivo();
		
		int contadorDeLidos=0;
		int tamanhoMatrix=0;
		
		// ------------------------------ LER O ARQUIVO -----------------------------------//

		for(String linhaArquivo: linhasArquivoLidas)
		{
			
			//System.out.println("@@linhaArquivo"  + linhaArquivo);
			
			int contadorPontoVirgula=0;
			int posicaoAnteriorCaracter=0;
			int contadorVariaveis=0;

			
			// Ler o header para pegar a lista de todas as vari�veis
			for(int posicao=0;posicao<linhaArquivo.length();posicao++)
			{
				
				// alguns arquivo come�ar com ;
				if(linhaArquivo.charAt(posicao) ==  ';')
				{
					contadorPontoVirgula++;
					
					if(posicaoAnteriorCaracter < 1)
					{
						// n�o fazer nada
					}else
					{
						posicaoAnteriorCaracter = posicaoAnteriorCaracter+1;
					}

					String variavel = linhaArquivo.substring(posicaoAnteriorCaracter,posicao);
					// armazena vari�vel
					if(variavel != null && !variavel.contentEquals(" ") && !variavel.contentEquals( "0") && !variavel.contentEquals("1") && contadorDeLidos==0)
					{
						// Achou uma vari�vel
						//System.out.println("Variavel:" + variavel);
						//System.out.println("contadorVariaveis:" + contadorVariaveis);
						 
						mapaVertices.put(variavel, contadorVariaveis);
						mapaVerticesText.put(contadorVariaveis,variavel);
						contadorVariaveis++;
						tamanhoMatrix = contadorVariaveis;
					}
					
					posicaoAnteriorCaracter = posicao;
				}
			}
			
			// Pegar �ltima vari�vel		

			String variavel = linhaArquivo.substring(posicaoAnteriorCaracter+1,linhaArquivo.length());
			
			// armazena vari�vel
			if(variavel != null && !variavel.contentEquals(" ") && !variavel.contentEquals( "0") && !variavel.contentEquals("1") && contadorDeLidos==0)
			{
				//System.out.println("Variavel:" + variavel);
				//System.out.println("contadorVariaveis:" + contadorVariaveis);
				mapaVertices.put(variavel, contadorVariaveis);
				mapaVerticesText.put(contadorVariaveis,variavel);			
				contadorVariaveis++;	
				tamanhoMatrix = contadorVariaveis;
			}

			
			//System.out.println("@@Contador de Vari�veis"  + contadorPontoVirgula);
			contadorPontoVirgula=0;
			contadorDeLidos++;
			
		}
		
		System.out.println("@@tamanhoMatrix"  + tamanhoMatrix);
		
		//Definir matrix de valores
		int [][] network = new int [tamanhoMatrix][tamanhoMatrix]; 
		contadorDeLidos=0;
		boolean primeiraleitura=true;
		
		for(String linhaArquivo: linhasArquivoLidas)
		{
	
			//pula header
			if(primeiraleitura ==true)
			{
				primeiraleitura = false;
				 continue;
			}

			//System.out.println("@@linhaArquivo"  + linhaArquivo);
			
			int contadorPontoVirgula=0;
			int posicaoAnteriorCaracter=0;
			int contadorVariaveis=0;
			
			String funcionalidade = "";
			boolean StepsDefuncionalidade = false;
			
			// Ler o header para pegar a lista de todas as vari�veis
			for(int posicao=0;posicao<linhaArquivo.length();posicao++)
			{
				
				// alguns arquivo come�ar com ;
				if(linhaArquivo.charAt(posicao) ==  ';')
				{
					contadorPontoVirgula++;
					
					if(posicaoAnteriorCaracter < 1)
					{
						// n�o fazer nada
					}else
					{
						posicaoAnteriorCaracter = posicaoAnteriorCaracter+1;
					}

					String variavel = linhaArquivo.substring(posicaoAnteriorCaracter,posicao);

					// Armazenar funcionalidade
					//if(variavel.contains("FUNCIONALIDADE"))
					
					if(variavel.contains("01p2T000000J6kbQAC-EK6_DadoCadastralCommandTest-ApexClass"))
					{
						System.out.println("Funcionalidade:" + variavel);	
						funcionalidade = variavel;
						
						StepsDefuncionalidade = true;
					}else
					{
						if(StepsDefuncionalidade == true && variavel.contentEquals("1"))
						{
							System.out.println("componentes:" + mapaVerticesText.get(Integer.valueOf(contadorVariaveis)));
							mapaFuncionalidadesXcomponentes.put(mapaVerticesText.get(Integer.valueOf(contadorVariaveis)),funcionalidade);
						}
						
					}

					// Armazena vari�vel
					if(variavel != null && (variavel.contentEquals( "0") || variavel.contentEquals("1")))
					{
						// Achou uma vari�vel
						//System.out.println("Variavel:" + variavel);
						//System.out.println("contadorVariaveis:" + contadorVariaveis);
	
						network[contadorDeLidos][contadorVariaveis] = Integer.valueOf(variavel);
	
						contadorVariaveis++;
					}
					
					posicaoAnteriorCaracter = posicao;
				}
			}
			
			// Pegar �ltima vari�vel		

			String variavel = linhaArquivo.substring(posicaoAnteriorCaracter+1,linhaArquivo.length());
			
			// armazena vari�vel
			if(variavel != null && (variavel.contentEquals("0") || variavel.contentEquals("1")) )
			{
				System.out.println("Variavel:" + variavel);
				//System.out.println("contadorVariaveis:" + contadorVariaveis);
				//System.out.println("contadorDeLidos:" + contadorDeLidos);	
				
				network[contadorDeLidos][contadorVariaveis] = Integer.valueOf(variavel);
				//mapaVertices.put(variavel, contadorVariaveis);
				//mapaVerticesText.put(contadorVariaveis,variavel);
				contadorVariaveis++;	
			}

			
			//System.out.println("@@Contador de Vari�veis"  + contadorPontoVirgula);
			contadorPontoVirgula=0;
			

			contadorDeLidos++;
			
			
			//contadorDeLidos--;//diminui em fun��o do head
			
			
		}		
		
		// imprime matrix - Rede com valores
		for(int x=0;x<12;x++)
		{
			for(int y=0;y<12;y++)
			{
				
				System.out.println("network["+x+"]" + "[" + y + "]" + ":" + network[x][y]);
				
				
				
			}
			
			
		}
		
		// Funcionalidade
		//String funcionalidadeBuscada = "FUNCIONALIDADE4";
		String funcionalidadeBuscada = "01p2T000000J6kbQAC-EK6_DadoCadastralCommandTest-ApexClass"; 
		// buscar sub arvore do componente
		
		
		// buscar por funcionalidade
		mapaSubArvore = buscaUnlockedPackageFuncionalidade(funcionalidadeBuscada, network, tamanhoMatrix, mapaVertices, mapaVerticesText, mapaFuncionalidadesXcomponentes, mapaSubArvore);
		
		// Criar sub �rvore
		subarvore(tamanhoMatrix, funcionalidadeBuscada,network, mapaVertices, mapaVerticesText, mapaFuncionalidadesXcomponentes, funcionalidadeBuscada, mapaSubArvore);
		
	}
	
	// Busca unlocked package por funcionalidade - Por funcionalidade
	public static Map<String,String> buscaUnlockedPackageFuncionalidade(String funcionalidade, int [][] network, int tamanhoMatrix, Map<String,Integer> mapaVertices,Map<Integer,String> mapaVerticesText, Map<String,String> mapaFuncionalidadesXcomponentes, Map<String,String> mapaSubArvore )
	{
		int variavelPosicao = mapaVertices.get(funcionalidade);

		// Componentes montado em tempo real
		Map<Integer,String>  mapaVerticesRealTime = new HashMap<Integer,String>();
		
		System.out.println("funcionalidade:" + funcionalidade);
		System.out.println("funcionalidade-variavelPosicao:" + variavelPosicao);
		
		List<Integer> dependenciasTotais = new ArrayList<Integer>();
		
		// buscar primeiras depedencias
		List<Integer> Primeiradependencias = percorreDepedencias(network, variavelPosicao, tamanhoMatrix, mapaVerticesRealTime,mapaVerticesText);
		
		
		// atribuir resultados
		/*for(Integer posicaoComponente: Primeiradependencias)
		{
			//System.out.println("Dependencia:" + mapaVerticesText.get(posicaoComponente));
			
		 
		}*/
		
		
		// Busca deped�ncias
		boolean buscaDependencia = true;
		while(buscaDependencia)
		{	
			//List<Integer> dependencias = percorreDepedencias(network, variavelPosicao, tamanhoMatrix);
			// atribuir resultados
			for(Integer posicaoComponente: Primeiradependencias)
			{
				//System.out.println("Dependencia:" + mapaVerticesText.get(posicaoComponente));
				
				List<Integer> dependencias = percorreDepedencias(network, posicaoComponente, tamanhoMatrix,mapaVerticesRealTime,mapaVerticesText);
				
				if(dependencias == null || dependencias.size() ==0)
				{
					buscaDependencia = false;
				}else
				{
					Primeiradependencias = dependencias;
				}
			}
			
			
		}
		
		// Imprimir Depend�ncia
		
		for(Integer value: mapaVerticesRealTime.keySet())
		{
			
			if(mapaSubArvore.get(mapaFuncionalidadesXcomponentes.get(mapaVerticesRealTime.get(value))) != mapaFuncionalidadesXcomponentes.get(mapaVerticesRealTime.get(value)))
			{
				mapaSubArvore.put(mapaFuncionalidadesXcomponentes.get(mapaVerticesRealTime.get(value)), mapaFuncionalidadesXcomponentes.get(mapaVerticesRealTime.get(value)));
			}
			
			if(mapaSubArvore.get(mapaVerticesRealTime.get(value)) != mapaFuncionalidadesXcomponentes.get(mapaVerticesRealTime.get(value)))
			{
				mapaSubArvore.put(mapaVerticesRealTime.get(value), mapaVerticesRealTime.get(value));
			}
			
			
			System.out.println("funcionalidade" + mapaFuncionalidadesXcomponentes.get(mapaVerticesRealTime.get(value)));
			System.out.println("Deped�ncia:" + mapaVerticesRealTime.get(value));
			
		}
		
		
		return mapaSubArvore;
		
	}

    // Criar sub-�rvore
	
	public static void subarvore(Integer tamanhoMatrix, String funcionalidade,int [][] network,Map<String,Integer> mapaVertices, Map<Integer,String> mapaVerticesText, Map<String,String> mapaFuncionalidadesXcomponentes, String funcionalidadeBuscada,Map<String,String> mapaSubArvore)
	{
		int numero=0;
		// Obter tamanho
		for(String componente :mapaSubArvore.keySet())
		{
		  System.out.println("componenteNaLista:" + componente + "|");

		  numero++;
		}
		
		//Definir matrix de valores
		//int [][] subarvore = new int [numero][numero]; 
		// copiar posi��es
		
	   /* for(int linhaColuna=0; linhaColuna<numero; linhaColuna++)
	    {
	    	//subarvore[][]
	    	
	    }*/
		//mapaVertices();
		int manterPosicao=99;
		
		for(int linha=0;linha<tamanhoMatrix;linha++)
		{
			System.out.println("componente-linha:" + linha);
			String componente = mapaVerticesText.get(linha);
			
			if(componente != null)
			{
			
			//System.out.println("componente:" + componente);
			//System.out.println("mapaSubArvore.get(componente) :" + mapaSubArvore.get(componente) );
			
			String compSubArvore = mapaSubArvore.get(componente);
			
			 if(compSubArvore != null)
			 {
				 	if(stringCompare(compSubArvore,componente) ==0 )
				 	{
				 		System.out.println("componente-MmapaSubArvore:" + mapaSubArvore.get(componente));
				 		System.out.println("componente-Manter:" + linha);
				 		manterPosicao = linha;
				 	} 
			 }
		
			
			}
			
			for(int coluna=0;coluna<tamanhoMatrix;coluna++)
			{
				 if(manterPosicao == coluna || manterPosicao == linha)
				 {
					 
				 }else
				 {
					 network[linha][coluna] = 0; 
				 }
				System.out.println("Sa�da Sub�rvore - network["+ linha+"]" + "[" + coluna + "]" + ":" + network[linha][coluna]);	
				
			}
			
			
		}
		
		// Gravar aquivo
		
		//Definindo Arquivo
		Arquivo arquivoDeConta = new Arquivo(funcionalidade+".csv", ".\\network\\");
				
		//arquivoDeConta.gravarArquivo("sss");
		int contador =0;
		String linhaDeDados = "";
		List<String> lines=new ArrayList<>();
				
		// Grava Header
				for(int linha=0;linha<tamanhoMatrix; linha++)
				{
					if(linha<(tamanhoMatrix - 1))
					{
						linhaDeDados = linhaDeDados + mapaVerticesText.get(linha) + ';';	
					}else
					{
						linhaDeDados = linhaDeDados + mapaVerticesText.get(linha);
					}
						
				}			
				arquivoDeConta.gravarArquivo(linhaDeDados);	
				
				//Imprime e Grava Matrix
				
				for(int linha=0;linha<tamanhoMatrix; linha++)
				{
					linhaDeDados ="";
					linhaDeDados = mapaVerticesText.get(linha) + ';';
					for(int coluna=0;coluna<tamanhoMatrix; coluna++)
					{
						//if(network[linha][coluna] ==1)
						//{
						contador ++;
						
						if(coluna<(tamanhoMatrix-1))
						{
							linhaDeDados = linhaDeDados + String.valueOf(network[linha][coluna]) + ";";
						}else
						{
							linhaDeDados = linhaDeDados + String.valueOf(network[linha][coluna]);
						}
						
						//lines.add(linhaDeDados);
						System.out.println("Linha:" + network[linha][coluna]);
						//}
					 }
					arquivoDeConta.gravarArquivo(linhaDeDados);
					//System.out.println("Linha:" + linha);
					//linha = tamanho + 40;
					
				}	
				

		
		
		
	}
	
	
	
	
	// Busca deped�ncia de um componentes 
	public static List<Integer> percorreDepedencias(int [][] network,int variavelPosicao, int tamanhoMatrix,Map<Integer,String> mapaVerticesRealTime,Map<Integer,String> mapaVerticesText)
	{
		List<Integer> dependecias = new ArrayList<Integer>();
		
		//Busca depd�ncias na linha
		for(int coluna=0;coluna<tamanhoMatrix;coluna++)
		{	
			// verifica se h� conex�o (Deped�ncia)
			if(network[variavelPosicao][coluna] == 1 && mapaVerticesRealTime.get(coluna) == null )
			{
				String nomeComponente = mapaVerticesText.get(coluna);
				mapaVerticesRealTime.put(coluna, nomeComponente);
				System.out.println("entrou:" + coluna );
				//dependecias.add(network[variavelPosicao][coluna]);
				dependecias.add(coluna);
			}

		}	
		
		return dependecias;
	}
	
	
    // This method compares two strings 
    // lexicographically without using 
    // library functions 
    public static int stringCompare(String str1, String str2) 
    { 
  
        int l1 = str1.length(); 
        int l2 = str2.length(); 
        int lmin = Math.min(l1, l2); 
  
        for (int i = 0; i < lmin; i++) { 
            int str1_ch = (int)str1.charAt(i); 
            int str2_ch = (int)str2.charAt(i); 
  
            if (str1_ch != str2_ch) { 
                return str1_ch - str2_ch; 
            } 
        } 
  
        // Edge case for strings like 
        // String 1="Geeks" and String 2="Geeksforgeeks" 
        if (l1 != l2) { 
            return l1 - l2; 
        } 
  
        // If none of the above conditions is true, 
        // it implies both the strings are equal 
        else { 
            return 0; 
        } 
    } 

}
