﻿#Add-Content output.txt $PSScriptRoot


$script:packagesProcessed = 0

$prettynames = (New-Object -Com Shell.Application).NameSpace('shell:::{4234d49b-0245-4df3-b780-3893943456e1}').Items()

# add all pretty names to a table that can be searched very quickly
# https://ss64.com/ps/syntax-hash-tables.html
$prettynamesHashTable = @{}
foreach ($item in $prettynames)
{
   # $line0 = $item.Name + ", " + $item.Path
  #  Write-Output $line0
  $prettynamesHashTable.Add($item.Path, $item.Name)
}

#Write-Output $prettynames.GetType()

Function GetPrettyName($launchAppName, $defaultPrettyname)
{
    if ($prettynamesHashTable.ContainsKey($launchAppName))
    {
        return $prettynamesHashTable.$($launchAppname)
    }
    return $defaultPrettyName
}

Function GetJsonString($key, $value)
{
    $retvalue = """$($key)"" : ""$($value)"""
    return $retvalue;
}


Function WriteJsonForApp($packageName, $packageFamilyName, $packageFullname, $installLocation, $Identify, $DisplayName, $Logo, $Id, $launchAppName, $launchCommand, $prettyName)
{
    $v1  = GetJsonString "PackageName"       $packageName
    $v2  = GetJsonString "packageFamilyName" $packageFamilyName
    $v3  = GetJsonString "packageFullname"   $packageFullname
    $v4  = GetJsonString "installLocation"   $installLocation
    $v5  = GetJsonString "Identify"          $Identify
    $v6  = GetJsonString "DisplayName"       $DisplayName
    $v7  = GetJsonString "Logo"              $Logo
    $v8  = GetJsonString "Id"                $Id
    $v9  = GetJsonString "launchAppName"     $launchAppName
    $v10 = GetJsonString "launchCommand"     $launchCommand
    $v11 = GetJsonString "prettyName"        $prettyName

    # build the output line
    $jsonLine = "{ " + $v1 + ", " + $v2 + ", " + $v3 + ", " + $v4 + ", " + $v5 + ", " + $v6 + ", " + $v7 + ", " + $v8 + ", " + $v9 + ", " + $v10 + ", " + $v11 + "}"

    # escape the backslashes for json
    $jsonLine2 = $jsonLine.replace("`\","`\`\")
    Write-Output $jsonLine2
}


Function WritePackageAsJson ($package, $masterPackage)
{
    try
    {
        $manifests = Get-AppxPackageManifest -Package $package
        foreach ($manifest in $manifests)
        {
            foreach($app in $manifest.Package.Applications.Application)
            {

                if ($package -eq $masterPackage)
                {
                    $launchAppname = $package.PackageFamilyName + "`!" + $app.Id
                    $launchCommand = "shell:appsFolder\$($package.PackageFamilyName)!$($app.Id)"
                }
                else
                {
                    $launchAppname = $masterPackage.PackageFamilyName + "`!" + $app.Id
                    $launchCommand = "shell:appsFolder\$($masterPackage.PackageFamilyName)!$($app.Id)"
                }
                $prettyName = GetPrettyName $launchAppname $manifest.Package.Properties.DisplayName

                if (!$prettyName.StartsWith("ms-resource:"))
                {
                    # if this isn't the first line, put comma at end of previous line
                    if ($script:packagesProcessed -gt 0)
                    {
                        Write-Output ","
                    }                   
                    $script:packagesProcessed++
                    
                    # write the info for this app
                    WriteJsonForApp $package.Name $package.PackageFamilyName $package.PackageFullName $package.installLocation $manifest.Package.Identity.GetAttribute("Name") $manifest.Package.Properties.DisplayName $manifest.Package.Properties.Logo $app.Id $launchAppname $launchCommand $prettyName
                }
            }
        }
    }
    catch
    {
        # Write-Warning "No manifest found for $($package.name)" 
    }
}



$packages = Get-AppxPackage

# write json header
Write-Output "{ ""packages"" : ["



foreach ($package in $packages)
{

# for each Dependency, get its manifest and look at each app
    if ($package.Name.equals("Microsoft.Office.Desktop"))
    {
       foreach ($dependency in $package.Dependencies)
       {
           WritePackageAsJson $dependency $package
       }
    }

    # write this package
    WritePackageAsJson $package $package
}

#write json footer
Write-Output "] }"

#Write-Output "Press any key to continue..."
#[void][System.Console]::ReadKey($true)